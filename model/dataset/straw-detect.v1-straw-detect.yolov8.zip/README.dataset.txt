# straw-detect > straw-detect
https://universe.roboflow.com/strawberry-detect/straw-detect-um7ho

Provided by a Roboflow user
License: CC BY 4.0

